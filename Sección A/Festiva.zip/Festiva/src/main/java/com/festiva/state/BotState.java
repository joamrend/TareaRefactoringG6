package com.festiva.state;

public enum BotState {

    IDLE,
    WAITING_FOR_ADD_FRIEND_INPUT,
    WAITING_FOR_REMOVE_FRIEND_INPUT
}
