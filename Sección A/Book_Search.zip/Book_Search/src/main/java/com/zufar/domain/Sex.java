package com.zufar.domain;

public enum Sex {
    MALE, FEMALE
}